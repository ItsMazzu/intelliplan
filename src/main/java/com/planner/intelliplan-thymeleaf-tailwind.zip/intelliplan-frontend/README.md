# IntelliPlan — Dashboard (Thymeleaf + Tailwind)

## Arquivos
- `src/main/resources/templates/dashboard.html`: template Thymeleaf da dashboard.
- `src/main/resources/static/css/dashboard.css`: estilos complementares e identidade visual.
- `src/main/resources/static/js/dashboard.js`: inicialização dos ícones e interação demonstrativa.

## Como integrar
1. Copie a pasta `src/main/resources/templates` e `src/main/resources/static` para o projeto Spring Boot, mesclando com as pastas existentes.
2. Crie um endpoint MVC que retorne a view `dashboard`.
3. Envie os atributos de modelo usados no template (veja abaixo). Se algum atributo ainda não existir, o template possui conteúdo demonstrativo para listas principais.

Exemplo de controller:

```java
@Controller
public class DashboardController {
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("usuarioNome", "Laís Campos");
        model.addAttribute("primeiroNome", "Laís");
        model.addAttribute("totalTarefas", 12);
        model.addAttribute("totalProjetos", 3);
        model.addAttribute("totalHabitos", 5);
        model.addAttribute("progressoGeral", 68);
        return "dashboard";
    }
}
```

## Atributos esperados para popular as listas
- `diasHabitos`: lista de objetos com `inicial` e `concluido`.
- `diasCalendario`: lista de objetos com `numero`, `hoje` e `temEvento`.
- `tarefasHoje`: lista com `id`, `titulo`, `concluida` e `categoria`.
- `projetosAtivos`: lista com `nome`, `descricao` e `progresso`.
- `materias`: lista com `nome`, `conteudoAtual` e `progresso`.
- `progressoTarefas`, `progressoEstudos`, `progressoHabitos`, `progressoProjetos`: valores textuais como `70%`.

## Observações
- O Tailwind está carregado pelo CDN para facilitar o primeiro teste. Para produção, instale e compile Tailwind no pipeline do projeto.
- O CSS complementar controla componentes específicos que não ficam tão legíveis apenas com classes utilitárias.
- Os links (`/tarefas`, `/projetos`, etc.) são rotas ilustrativas: ajuste para os endpoints reais da aplicação.
- O formulário de concluir tarefa pressupõe uma rota POST `/tarefas/{id}/concluir`; ajuste conforme seu controller e proteção CSRF.
- A imagem de referência foi traduzida em estrutura HTML/CSS, não embutida no template.
